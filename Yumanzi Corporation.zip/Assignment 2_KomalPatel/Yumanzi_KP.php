<?php
    function Yumanzi_Calculate($domesticCalls, $internationalCalls, $internationalTexts, $dataUsage)
    {
    // Constants Variables
    $domesticCallRate=0.05;
    $internationalTextRate=0.50;
    $internetPlanFixed=40;
    $overDataUsageRate=0.05;
    $internationalCallCost = 0; 

    //Calculate Bill for Domestic Calls
    $domesticCallBill=$domesticCalls*$domesticCallRate;

    
    // Calculate international call charges

    if ($internationalCalls <= 5) {
        // First 5 international calls are free
        $internationalCallBill = 0;
    } elseif ($internationalCalls <= 10) {
        // Calls 6 to 10 cost $5 per call
        $internationalCallBill = 5 * ($internationalCalls - 5);
    } elseif ($internationalCalls <= 20) {
        // Calls 11 to 20 cost $7 per call
        $internationalCallBill = 5 * 5 + 7 * ($internationalCalls - 10);
    } else {
        // More than 20 calls cost $8 per call
        $internationalCallBill = 5 * 5 + 7 * 10 + 8 * ($internationalCalls - 20);
    }

    //echo "domestic call is ".$domesticCall."<br>"."price of domestic call is ".$domeesticCallRate."<br>";

   // Calculate bill for international texts
   $internationalTextBill=$internationalTexts * $internationalTextRate;

   // Calculate bill for data usage
   $dataUsageBill=$dataUsage * $overDataUsageRate;

   // Calculate total bill before tax
   $totalBill=$domesticCallBill + $internationalCallBill + $internationalTextBill + $dataUsageBill + $internetPlanFixed;

   //Calculate tax
   $tax = $totalBill * 0.09;

   // Calculate final bill after tax
   $finalBill = $totalBill + $tax;

   return $finalBill;
    
}
// Variables to hold user inputs and error messages
$domesticCalls = $internationalCalls = $domesticTexts = $internationalTexts = $dataUsage = "";
$domesticCallsErr = $internationalCallsErr = $internationalTextsErr = $dataUsageErr = "";

//check if the form is recieving input
if(isset($_POST["calculate"]))
{
    $domesticCalls=$_POST['domesticCalls'];
    $internationalCalls=$_POST['internationalCalls'];
    $internationalTexts=$_POST['internationalTexts'];
    $dataUsage=$_POST['dataUsage'];
    //$finalBill=Yumanzi_Calculate($domesticCalls, $internationalCalls, $internationalTexts, $dataUsage);
    
    if (empty($domesticCalls)) {
        $domesticCallsErr = 'Please enter the number of domestic calls.';
    }

    if (empty($internationalCalls)) {
        $internationalCallsErr = 'Please enter the number of international calls.';
    }

    if (empty($internationalTexts)) {
        $internationalTextsErr = 'Please enter the number of international texts.';
    }
    if (empty($dataUsage)) {
        $dataUsageErr = 'Please enter the number of data used.';
    }

    if (!empty($errorMessages)) {
        foreach ($errorMessages as $errorMessage) {
            echo $errorMessage . "<br>";
        }
    }
    
}

// Function to sanitize user input
function sanitizeInput($input)
{
    $input = trim($input);
    $input = stripslashes($input);
    $input = htmlspecialchars($input);
    return $input;
}

  
?>

<html>
    
    <style>
        #dc{
            width :20%;
        }
        #ic{
            width :20%;
        }
        #it{
            width :20%;
        }
        #du{
            width :20%;
        }
        .error{
            color:#FF0001;
        }
        
        </style>
    <body>
        <h1>Yumanzi Corporation-Calculate Telephone Bill</h1>
    <form action="" method="POST">
    <input type="number" id="dc" name="domesticCalls" placeholder="Please enter no. of domestic call" required><br><br>
    <span class="error"><?php echo $domesticCallsErr; ?></span><br>
    <input type="number" id="ic" name="internationalCalls" placeholder="Please enter no. of international call" required><br><br>
    <span class="error"><?php echo $internationalCallsErr; ?></span><br>
    <input type="number" id="it" name="internationalTexts" placeholder="Please enter no. of international texts" required><br><br>
    <span class="error"><?php echo $internationalTextsErr; ?></span><br>
    <input type="number" id="du" name="dataUsage" placeholder="Please enter over data usage in MB " required><br><br>  
    <span class="error"><?php echo $dataUsageErr; ?></span><br>
    <input type="Submit" name="calculate"><br>
    
    </form>

    <?php
    if(isset($_POST['calculate'])){
        $finalBill=Yumanzi_Calculate($domesticCalls, $internationalCalls, $internationalTexts, $dataUsage);
        $i=$finalBill;
        echo "<h2>Total Bill After Tax is :".$finalBill."</h3>";
        for($i= 0;$i <5; $i++){
            echo "<b>Total bill: ".$finalBill."</b><br>";
        }

    }

    ?>
    </body>
</html>

    
    
